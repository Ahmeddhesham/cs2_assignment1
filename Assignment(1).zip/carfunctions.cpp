#include <iostream>
#include "car.h"
using namespace std;

car::car() {
	car_brand = "";
	car_type = "";
	car_plate = "";
	speed = 0;
	year_model = 0;
}

car::car(string car_b, int max_speed, int yearmod) {
	car_brand = car_b;
	speed = max_speed;
	year_model = yearmod;
}

void car::setcarbrand(string brand) {
	car_brand = brand;
}

void car::setcartype(string type) {
	car_type = type;
}

void car::setcarplate(string plate) {
	car_plate = plate;
}

void car::setspeed(int carspeed) {
	speed = carspeed;
}

void car::setyearmodel(int year) {
	year_model = year;
}


string car::getcarbrand() {
	return car_brand;
}

string car ::getcartype() {
	return car_type;
}

string car::getcarplate() {
	return car_plate;
}

int car::getcarspeed() {
	return speed;
}

int car::getyearmodel() {
	return year_model;
}