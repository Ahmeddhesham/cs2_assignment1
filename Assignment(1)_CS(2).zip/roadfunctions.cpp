#include <iostream>
#include "road.h"
#include <cctype>
using namespace std;

road::road() {
	road_type = ' ';
	speed_limit = 0;
	countA = 0.0;
	countB = 0.0;
	countC = 0.0;
}

road::road(char road, int speed) {
	road_type = road;
	speed_limit = speed;
}

void road::setroadtype(char roadtype) {
	road_type = roadtype;
}

void road::setspeedlimit(int speed) {
	speed_limit = speed;
}

void road:: setcountA(int counter) {
	countA = counter;
}

void road::setcountB(int counter) {
	countB = counter;
}

void road:: setcountC(int counter) {
	countC = counter;
}

char road::getroadtype() {
	return road_type;
}

int road::getspeedlimit() {
	return speed_limit;
}

int road::getcountA() {
	return countA;
}

int road::getcountB() {
	return countB;
}

int road::getcountC() {
	return countC;
}

bool road :: radar(int carspeed, char type) {
	toupper(type);

	if (type == 'A') {
		setspeedlimit(90);
	}

	if (type == 'B') {
		setspeedlimit(75);
	}

	if (type == 'C') {
		setspeedlimit(60);
	}

	if (carspeed > getspeedlimit()) {
		return true;
	}
	else {
		return false;
	}
}

void road::allow(string car_type) {
	char choice;
	bool notallowed = false;
	do {
		cout << "Enter the road you wish to take ( A, B, C): "<<endl<<"Road A: Allow only Private and motorcycle vehicles."<<endl<<
			"Road B : Allow all vehicles"<<endl<<
			"Road C : Allow only trucks."<<endl;
		cin >> choice;
		cout << endl;
		toupper(choice);

		if (choice == 'A' && (car_type == "Private"|| car_type =="Motorcycle")) {
			cout << "You are allowed on this road." << endl;
			setroadtype('A');
			setcountA(countA + 1);
			
			return;
		}

		else if (choice == 'B') {
			cout << "You are allowed on this road." << endl;
			setroadtype('B');
			setcountB(countB + 1);
			
			return;
		}

		else if (choice == 'C' && car_type == "Truck") {
			cout << "You are allowed on this road." << endl;
			setroadtype('C');
			setcountC(countC + 1);
			
			return;
		}
		else {
			cout << "You are not allowed on this road." << endl;
			notallowed = true;
		}
	} while (notallowed);
}

int road::age(int year_model) {

	return 2022 - year_model;
}