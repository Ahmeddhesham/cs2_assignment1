#pragma once
#include <iostream>'
using namespace std;

class car {
private:
	string car_brand;
	string car_type;
	string car_plate;
	int speed;
	int year_model;

public:
	car();
	car(string car_b, int max_speed, int yearmod);
	void setcarbrand(string brand);
	void setcartype(string type);
	void setcarplate(string plate);
	void setspeed(int carspeed);
	void setyearmodel(int year);
	string getcarbrand();
	string getcartype();
	string getcarplate();
	int getcarspeed();
	int getyearmodel();
};