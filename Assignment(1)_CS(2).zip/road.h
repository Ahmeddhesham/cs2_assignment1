#pragma once
#include <iostream>
using namespace std;

class road {
private:
	char road_type;
	int speed_limit;
	float countA, countB, countC;

public:
	road();
	road(char road, int speed);
	void setroadtype(char roadtype);
	void setspeedlimit(int speed);
	void setcountA(int counter);
	void setcountB(int counter);
	void setcountC(int counter);
	char getroadtype();
	int getspeedlimit();
	int getcountA();
	int getcountB();
	int getcountC();
	bool radar(int carspeed, char type);
	void allow(string car_type);
	int age(int year_model);
};