#include <iostream>
#include <queue>;
#include "car.h"
#include "road.h"

using namespace std;

void roadefficiency(int x, int y, int z);

void main() {
	queue <car> carQ;
	int n;
	cout << "Enter the number of cars: ";
	cin >> n;
	car* cars = new car[n];
	string car_brand;
	string car_type;
	string car_plate;
	int speed;
	int year_model;
	road roads;
	bool fined = false;
	

	for (int i = 0; i < n; i++) {
		cout << "For your " << i + 1 << " car:" << endl;
		cout << "Enter car brand: ";
		cin >> car_brand;
		cout << "Enter car type (e.g: Bus, Private, Motorcycle, Truck): ";
		cin >> car_type;
		cout << "Enter car plate: ";
		cin >> car_plate;
		cout << "Enter car speed: ";
		cin >> speed;
		cout << "Enter the car model year: ";
		cin >> year_model;

		cars[i].setcarbrand(car_brand);
		cars[i].setcartype(car_type);
		cars[i].setcarplate(car_plate);
		cars[i].setspeed(speed);
		cars[i].setyearmodel(year_model);

		carQ.push(cars[i]);
	}

	//I will call function allow before radar as i have to know which road they are on before telling the radar.
	int carnumber = 1;
	while (!(carQ.empty())) {
		cout << endl;
		cout << "This is the " << carnumber << " car:" << endl;
		cout << endl;
		roads.allow(carQ.front().getcartype());

		fined = roads.radar(carQ.front().getcarspeed(), roads.getroadtype());

		if (fined) {
			

			cout << "Car Brand: "<<carQ.front().getcarbrand() << endl;
			cout << "Car type: " << carQ.front().getcartype() << endl;
			cout << "Car plate: " << carQ.front().getcarplate() << endl;
			cout << "car speed: " << carQ.front().getcarspeed() << endl;
			cout << "Car model year: " << carQ.front().getyearmodel() << endl;
			cout << "This car will be fined" << endl;
		}

		cout << "The car's age is: " << roads.age(carQ.front().getyearmodel())<<endl;

		carQ.pop();
		carnumber++;
	}
	cout << endl;
	roadefficiency(roads.getcountA(), roads.getcountB(), roads.getcountC());

}

void roadefficiency(int x, int y, int z) {
	float highest = 0.0;
	if (highest < x) {
		highest = x;
	}
	if (highest < y) {
		highest = y;
	}
	if (highest < z) {
		highest = z;
	}

	cout << "Road A efficiency: " << (x / highest) * 100.0<<endl;
	cout << "Road B efficiency: " << (y / highest) * 100.0 << endl;
	cout << "Road C efficiency: " << (z / highest) * 100.0 << endl;
}